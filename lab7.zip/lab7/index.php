<!doctype html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <title>Home</title>
      <link rel="stylesheet" href="mystyle.css">
  </head>
  <body>
   <h1>Projekt za xml</h1>
   <h2>made by Fran Milisavljević</h2>
   <p>Cilj ovog projekta je članke koji su spremljeni u xml datoteci ispisati u browseru.</p>
    <?php
        $xml=simplexml_load_file('kod.xml');
        foreach($xml->clanak as $u){?>
            <div>
                <h2><?php echo $u->naslov;?></h2>
                <img src="slike/<?php echo $u->slika;?>">
                <h4><?php echo $u->datum;?></h4>
                <p><?php echo $u->sadrzaj;?></p>
			</div>
			<hr/>
    <?php }?>

  </body>
</html>